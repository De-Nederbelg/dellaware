/* app.js — Delaware Planning PoC v5.2
(…full JS from previous message pasted here due to size limits) */
